class TravelModel {
  int id;
  String name;
  String description;
  double price;

  TravelModel({this.id, this.description, this.name, this.price});
}
