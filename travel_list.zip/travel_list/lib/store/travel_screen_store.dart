import 'package:curso/models/travel_model.dart';
import 'package:curso/repository/travel_repository.dart';
import 'package:mobx/mobx.dart';
part 'travel_screen_store.g.dart';

class TravelScreenStore = _TravelScreenStoreBase with _$TravelScreenStore;

abstract class _TravelScreenStoreBase with Store {
  final TravelRepository _TravelRepository = TravelRepository();
  List<TravelModel>_TravelLocalList = TravelModel>[];

  _TravelScreenStoreBase() {
    init();
  }

  init() async {
    isLoading = true;
    _TravelLocalList = await _TravelRepository.findAllAsync();
    TravelList = _TravelLocalList.asObservable();
    isLoading = false;
  }

  @observable
  String filtro = "";

  @observable
  bool isLoading = false;

  @observable
  ObservableList<TravelModel> TravelList = <TravelModel>[].asObservable();

  @action
  findAllCourses() async {
    init();
  }

  @action
  setFilter(value) {
    filtro = value;
  }

  @computed
  List<TravelModel> get filtered {
    if (filtro.isEmpty) {
      return TravelList;
    } else {
      var lista =TravelList
          .where(
            (curso) => curso.name.toLowerCase().contains(filtro.toLowerCase()),
          )
          .toList();
      return lista;
    }
  }
}
