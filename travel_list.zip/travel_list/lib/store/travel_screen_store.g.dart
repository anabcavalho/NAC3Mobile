// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'travel_screen_store.dart';

// **************************************************************************
// StoreGenerator
// **************************************************************************

// ignore_for_file: non_constant_identifier_names, unnecessary_brace_in_string_interps, unnecessary_lambdas, prefer_expression_function_bodies, lines_longer_than_80_chars, avoid_as, avoid_annotating_with_dynamic

mixin _$TravelScreenStore on _TravelScreenStoreBase, Store {
  Computed<List<TravelModel>> _$filteredComputed;

  @override
  List<TravelModel> get filtered =>
      (_$filteredComputed ??= Computed<List<TravelModel>>(() => super.filtered,
              name: '_TravelScreenStoreBase.filtered'))
          .value;

  final _$filtroAtom = Atom(name: '_TravelScreenStoreBase.filtro');

  @override
  String get filtro {
    _$filtroAtom.reportRead();
    return super.filtro;
  }

  @override
  set filtro(String value) {
    _$filtroAtom.reportWrite(value, super.filtro, () {
      super.filtro = value;
    });
  }

  final _$isLoadingAtom = Atom(name: '_TravelScreenStoreBase.isLoading');

  @override
  bool get isLoading {
    _$isLoadingAtom.reportRead();
    return super.isLoading;
  }

  @override
  set isLoading(bool value) {
    _$isLoadingAtom.reportWrite(value, super.isLoading, () {
      super.isLoading = value;
    });
  }

  final _$TravelListAtom = Atom(name: '_TravelScreenStoreBase.travelList');

  @override
  ObservableList<TravelModel> get TravelList {
    _$TravelListAtom.reportRead();
    return super.TravelList;
  }

  @override
  set TravelList(ObservableList<TravelModel> value) {
    _$TravelListAtom.reportWrite(value, superTravelList, () {
      super.TravelList = value;
    });
  }

  final _$findAllCoursesAsyncAction =
      AsyncAction('_TravelScreenStoreBase.findAllCourses');

  @override
  Future findAllCourses() {
    return _$findAllCoursesAsyncAction.run(() => super.findAllCourses());
  }

  final _$_TravelScreenStoreBaseActionController =
      ActionController(name: '_TravelScreenStoreBase');

  @override
  dynamic setFilter(dynamic value) {
    final _$actionInfo = _$_TravelScreenStoreBaseActionController.startAction(
        name: '_TravelScreenStoreBase.setFilter');
    try {
      return super.setFilter(value);
    } finally {
      _$_TravelScreenStoreBaseActionController.endAction(_$actionInfo);
    }
  }

  @override
  String toString() {
    return '''
filtro: ${filtro},
isLoading: ${isLoading},
TravelList: ${TravelList},
filtered: ${filtered}
    ''';
  }
}
