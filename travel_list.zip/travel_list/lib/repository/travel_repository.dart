mport 'package:curso/models/travel_model.dart';

import 'database_helper.dart';

class TravelRepository {
  Future<List<TravelModel>> findAllAsync() async {
    var db = DatabaseHelper();
    await db.createDatabase();

    ListTravelModel> travel = [];

    if (db.created) {
      travel = [];

      travel.add(
        new TravelModel(
            id: 1, description: "Descrição 1", name: "Viagem 1", price: 250.00),
      );
      travel.add(
        TravelModel(
            id: 2, description: "Descrição 2", name: "Viagem 2", price: 480.00),
      );
      travel.add(
      TravelModel(
            id: 3, description: "Descrição 3", name: "Viagem 3", price: 650.00),
      );
      travel.add(
        TravelModel(
            id: 4, description: "Descrição 4", name: "Viagem 4", price: 800.00),
      );
    }

    return new Future.value(travel);
  }
}
