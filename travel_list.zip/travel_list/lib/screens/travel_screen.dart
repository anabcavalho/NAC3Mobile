import 'package:curso/screens/widget/travel_listview.dart';
import 'package:curso/screens/widget/travel_listview_loading.dart';
import 'package:curso/store/travel_screen_store.dart';
import 'package:flutter/material.dart';
import 'package:flutter_mobx/flutter_mobx.dart';

class TravelScreen extends StatefulWidget {
  @override
  _TravelScreenState createState() => _TravelScreenState();
}

class _TravelScreenState extends State<TravelScreen> {
  final scaffoldKey = GlobalKey<ScaffoldState>();

  final TravelScreenStore TravelScreenStore = TravelScreenStore();

  @override
  void initState() {
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      key: scaffoldKey,
      appBar: AppBar(
          backgroundColor: Color.fromRGBO(195, 100, 100, .9),
          title: Observer(
            builder: (_) {
              return Text("Itens na lista: " +
                  TravelScreenStore.travelList.length.toString());
            },
          )),
      body: Observer(
        builder: (ctx) {
          if (TravelScreenStore.isLoading) {
            return CursoListViewLoading();
          } else {
            return CursoListView(
              cursos: TravelScreenStore.filtered,
            );
          }
        },
      ),
      floatingActionButton: FloatingActionButton(
        backgroundColor: Color.fromRGBO(195, 100, 100, .9),
        child: Icon(Icons.cached),
        onPressed: TravelScreenStore.findAllCourses,
      ),
    );
  }
}
